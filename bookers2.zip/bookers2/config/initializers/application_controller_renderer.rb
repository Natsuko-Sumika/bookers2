# Be sure to restart your server when you modify this file.

# ActiveSupport::Reloader.to_prepare do
#   ApplicationController.renderer.defaults.merge!(
#     http_host: 'example.org',
#     https: false
#   )
# end
Refile.secret_key = 'b3537f38c9a7e77124f021a9cdc931c64db574aacc09d93c4ded2ebc19a4974a23b96296d54343b20ff9d2545dfe067497504145b92cc1b7a2ef55f16ec97ded'